package android.support.v7.transition;

import android.view.ViewGroup;

public class ActionBarTransition {
  private static final boolean TRANSITIONS_ENABLED = false;
  
  private static final int TRANSITION_DURATION = 120;
  
  public static void beginDelayedTransition(ViewGroup paramViewGroup) {}
}


/* Location:              C:\Users\fnwin\source\dev\nx-mini\com.samsungimaging.connectionmanager\classes-dex2jar.jar!\android\support\v7\transition\ActionBarTransition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */